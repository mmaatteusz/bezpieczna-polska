# LEVELS

Właściciel / operator: RCB

URL: https://www.gov.pl/web/rcb/stopnie-alarmowe2

API / RSS / XML / HTML: Niezaimplementowane

Częstotliwość: nie ustalono — adapter nieaktywny

Limit: brak potwierdzonego limitu/SLA.

Autoryzacja: do weryfikacji

Licencja i regulamin: patrz docs/SOURCES.md; publikacja produkcyjna wymaga weryfikacji warunków ponownego użycia.

Backup source: nie skonfigurowano.

Ryzyko zmiany formatu: kontrakt do monitorowania; niedziałający parser nie oznacza braku zagrożeń
